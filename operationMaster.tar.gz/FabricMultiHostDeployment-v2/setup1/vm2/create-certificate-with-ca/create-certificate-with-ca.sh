createCretificateForOrderer() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p ../crypto-config/ordererOrganizations/device2.net

  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config/ordererOrganizations/device2.net

  fabric-ca-client enroll -u https://admin:adminpw@localhost:8054 --caname ca.device2.net --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-device2-net.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-device2-net.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-device2-net.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-device2-net.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config/ordererOrganizations/device2.net/msp/config.yaml

  echo
  echo "Register orderer2"
  echo

  fabric-ca-client register --caname ca.device2.net --id.name orderer2 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  echo
  echo "Register orderer3"
  echo

  fabric-ca-client register --caname ca.device2.net --id.name orderer3 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  echo
  echo "Register the orderer admin"
  echo

  fabric-ca-client register --caname ca.device2.net --id.name ordererAdmin --id.secret ordererAdminpw --id.type admin --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  mkdir -p ../crypto-config/ordererOrganizations/device2.net/orderers
  # mkdir -p ../crypto-config/ordererOrganizations/device2.net/orderers/device2.net

  # ---------------------------------------------------------------------------
  #  Orderer 2

  mkdir -p ../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net

  echo
  echo "## Generate the orderer2 msp"
  echo

  fabric-ca-client enroll -u https://orderer2:ordererpw@localhost:8054 --caname ca.device2.net -M ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/msp --csr.hosts orderer2.device2.net --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/msp/config.yaml ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/msp/config.yaml

  echo
  echo "## Generate the orderer2-tls certificates"
  echo

  fabric-ca-client enroll -u https://orderer2:ordererpw@localhost:8054 --caname ca.device2.net -M ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls --enrollment.profile tls --csr.hosts orderer2.device2.net --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls/ca.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls/signcerts/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls/server.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls/keystore/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls/server.key

  mkdir ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/msp/tlscacerts
  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/msp/tlscacerts/tlsca.device2.net-cert.pem

  mkdir ${PWD}/../crypto-config/ordererOrganizations/device2.net/msp/tlscacerts
  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer2.device2.net/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/msp/tlscacerts/tlsca.device2.net-cert.pem

  # -----------------------------------------------------------------------
  #  Orderer 3

  mkdir -p ../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net

  echo
  echo "## Generate the orderer3 msp"
  echo

  fabric-ca-client enroll -u https://orderer3:ordererpw@localhost:8054 --caname ca.device2.net -M ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/msp --csr.hosts orderer3.device2.net --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/msp/config.yaml ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/msp/config.yaml

  echo
  echo "## Generate the orderer3-tls certificates"
  echo

  fabric-ca-client enroll -u https://orderer3:ordererpw@localhost:8054 --caname ca.device2.net -M ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/tls --enrollment.profile tls --csr.hosts orderer3.device2.net --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/tls/ca.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/tls/signcerts/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/tls/server.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/tls/keystore/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/tls/server.key

  mkdir ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/msp/tlscacerts
  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/device2.net/orderers/orderer3.device2.net/msp/tlscacerts/tlsca.device2.net-cert.pem

  # ---------------------------------------------------------------------------

  mkdir -p ../crypto-config/ordererOrganizations/device2.net/users
  mkdir -p ../crypto-config/ordererOrganizations/device2.net/users/Admin@device2.net

  echo
  echo "## Generate the admin msp"
  echo

  fabric-ca-client enroll -u https://ordererAdmin:ordererAdminpw@localhost:8054 --caname ca.device2.net -M ${PWD}/../crypto-config/ordererOrganizations/device2.net/users/Admin@device2.net/msp --tls.certfiles ${PWD}/fabric-ca/device2/tls-cert.pem

  cp ${PWD}/../crypto-config/ordererOrganizations/device2.net/msp/config.yaml ${PWD}/../crypto-config/ordererOrganizations/device2.net/users/Admin@device2.net/msp/config.yaml

}

createCretificateForOrderer