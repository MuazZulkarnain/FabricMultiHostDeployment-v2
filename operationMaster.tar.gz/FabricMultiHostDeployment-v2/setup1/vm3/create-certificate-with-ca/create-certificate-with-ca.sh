createcertificatesForDevice3() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p ../crypto-config/peerOrganizations/device3.net/
  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config/peerOrganizations/device3.net/

  fabric-ca-client enroll -u https://admin:adminpw@localhost:10054 --caname ca.device3.net --tls.certfiles ${PWD}/fabric-ca/device3/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-device3-net.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-device3-net.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-device3-net.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-device3-net.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config/peerOrganizations/device3.net/msp/config.yaml

  echo
  echo "Register endorser"
  echo
  fabric-ca-client register --caname ca.device3.net --id.name endorser --id.secret endorserpw --id.type peer --tls.certfiles ${PWD}/fabric-ca/device3/tls-cert.pem

  echo
  echo "Register user"
  echo
  fabric-ca-client register --caname ca.device3.net --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/fabric-ca/device3/tls-cert.pem

  echo
  echo "Register the org admin"
  echo
  fabric-ca-client register --caname ca.device3.net --id.name device3admin --id.secret device3adminpw --id.type admin --tls.certfiles ${PWD}/fabric-ca/device3/tls-cert.pem

  mkdir -p ../crypto-config/peerOrganizations/device3.net/peers

  # -----------------------------------------------------------------------------------
  #  Peer 0
  mkdir -p ../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net

  echo
  echo "## Generate the endorser msp"
  echo
  fabric-ca-client enroll -u https://endorser:endorserpw@localhost:10054 --caname ca.device3.net -M ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/msp --csr.hosts endorser.device3.net --tls.certfiles ${PWD}/fabric-ca/device3/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device3.net/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/msp/config.yaml

  echo
  echo "## Generate the endorser-tls certificates"
  echo
  fabric-ca-client enroll -u https://endorser:endorserpw@localhost:10054 --caname ca.device3.net -M ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls --enrollment.profile tls --csr.hosts endorser.device3.net --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/device3/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/ca.crt
  cp ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/signcerts/* ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/server.crt
  cp ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/keystore/* ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/server.key

  mkdir ${PWD}/../crypto-config/peerOrganizations/device3.net/msp/tlscacerts
  cp ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device3.net/msp/tlscacerts/ca.crt

  mkdir ${PWD}/../crypto-config/peerOrganizations/device3.net/tlsca
  cp ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device3.net/tlsca/tlsca.device3.net-cert.pem

  mkdir ${PWD}/../crypto-config/peerOrganizations/device3.net/ca
  cp ${PWD}/../crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/msp/cacerts/* ${PWD}/../crypto-config/peerOrganizations/device3.net/ca/ca.device3.net-cert.pem

  # ------------------------------------------------------------------------------------------------

  mkdir -p ../crypto-config/peerOrganizations/device3.net/users
  mkdir -p ../crypto-config/peerOrganizations/device3.net/users/User1@device3.net

  echo
  echo "## Generate the user msp"
  echo
  fabric-ca-client enroll -u https://user1:user1pw@localhost:10054 --caname ca.device3.net -M ${PWD}/../crypto-config/peerOrganizations/device3.net/users/User1@device3.net/msp --tls.certfiles ${PWD}/fabric-ca/device3/tls-cert.pem

  mkdir -p ../crypto-config/peerOrganizations/device3.net/users/Admin@device3.net

  echo
  echo "## Generate the org admin msp"
  echo
  fabric-ca-client enroll -u https://device3admin:device3adminpw@localhost:10054 --caname ca.device3.net -M ${PWD}/../crypto-config/peerOrganizations/device3.net/users/Admin@device3.net/msp --tls.certfiles ${PWD}/fabric-ca/device3/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device3.net/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/device3.net/users/Admin@device3.net/msp/config.yaml

}

createcertificatesForDevice3

