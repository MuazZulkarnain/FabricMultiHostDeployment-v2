export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=${PWD}/../vm1/crypto-config/peerOrganizations/device1.net/tlsca/tlsca.device1.net-cert.pem
export ENDORSER_DEVICE4_CA=${PWD}/crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/ca.crt
export FABRIC_CFG_PATH=${PWD}/../../artifacts/channel/config/

export CHANNEL_NAME=mychannel

setGlobalsForEndorserDevice4() {
    export CORE_PEER_LOCALMSPID="Device4MSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$ENDORSER_DEVICE4_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/crypto-config/peerOrganizations/device4.net/users/Admin@device4.net/msp
    export CORE_PEER_ADDRESS=localhost:9051

}

fetchChannelBlock() {
    rm -rf ./channel-artifacts/*
    setGlobalsForEndorserDevice4

    # Replace localhost with your orderer's vm IP address
    peer channel fetch 0 ./../../artifacts/channel/$CHANNEL_NAME.block -o localhost:7050 \
        --ordererTLSHostnameOverride orderer1.device1.net \
        -c $CHANNEL_NAME --tls --cafile $ORDERER_CA
}

# fetchChannelBlock

joinChannel() {
    setGlobalsForEndorserDevice4
    peer channel join -b ./../../artifacts/channel/$CHANNEL_NAME.block
}

# joinChannel

updateAnchorPeers() {
    setGlobalsForEndorserDevice4

    # Replace localhost with your orderer's vm IP address
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer1.device1.net \
        -c $CHANNEL_NAME -f ./../../artifacts/channel/${CORE_PEER_LOCALMSPID}anchors.tx \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA

}

# updateAnchorPeers

fetchChannelBlock
joinChannel
updateAnchorPeers
