createcertificatesForDevice4() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p ../crypto-config/peerOrganizations/device4.net/
  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config/peerOrganizations/device4.net/

  fabric-ca-client enroll -u https://admin:adminpw@localhost:9054 --caname ca.device4.net --tls.certfiles ${PWD}/fabric-ca/device4/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-device4-net.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-device4-net.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-device4-net.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-device4-net.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config/peerOrganizations/device4.net/msp/config.yaml

  echo
  echo "Register endorser"
  echo
  fabric-ca-client register --caname ca.device4.net --id.name endorser --id.secret endorserpw --id.type peer --tls.certfiles ${PWD}/fabric-ca/device4/tls-cert.pem

  echo
  echo "Register user"
  echo
  fabric-ca-client register --caname ca.device4.net --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/fabric-ca/device4/tls-cert.pem

  echo
  echo "Register the org admin"
  echo
  fabric-ca-client register --caname ca.device4.net --id.name device4admin --id.secret device4adminpw --id.type admin --tls.certfiles ${PWD}/fabric-ca/device4/tls-cert.pem

  mkdir -p ../crypto-config/peerOrganizations/device4.net/peers

  # -----------------------------------------------------------------------------------
  #  Peer 0
  mkdir -p ../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net

  echo
  echo "## Generate the endorser msp"
  echo
  fabric-ca-client enroll -u https://endorser:endorserpw@localhost:9054 --caname ca.device4.net -M ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/msp --csr.hosts endorser.device4.net --tls.certfiles ${PWD}/fabric-ca/device4/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device4.net/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/msp/config.yaml

  echo
  echo "## Generate the endorser-tls certificates"
  echo
  fabric-ca-client enroll -u https://endorser:endorserpw@localhost:9054 --caname ca.device4.net -M ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls --enrollment.profile tls --csr.hosts endorser.device4.net --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/device4/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/ca.crt
  cp ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/signcerts/* ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/server.crt
  cp ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/keystore/* ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/server.key

  mkdir ${PWD}/../crypto-config/peerOrganizations/device4.net/msp/tlscacerts
  cp ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device4.net/msp/tlscacerts/ca.crt

  mkdir ${PWD}/../crypto-config/peerOrganizations/device4.net/tlsca
  cp ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device4.net/tlsca/tlsca.device4.net-cert.pem

  mkdir ${PWD}/../crypto-config/peerOrganizations/device4.net/ca
  cp ${PWD}/../crypto-config/peerOrganizations/device4.net/peers/endorser.device4.net/msp/cacerts/* ${PWD}/../crypto-config/peerOrganizations/device4.net/ca/ca.device4.net-cert.pem

  # ------------------------------------------------------------------------------------------------

  mkdir -p ../crypto-config/peerOrganizations/device4.net/users
  mkdir -p ../crypto-config/peerOrganizations/device4.net/users/User1@device4.net

  echo
  echo "## Generate the user msp"
  echo
  fabric-ca-client enroll -u https://user1:user1pw@localhost:9054 --caname ca.device4.net -M ${PWD}/../crypto-config/peerOrganizations/device4.net/users/User1@device4.net/msp --tls.certfiles ${PWD}/fabric-ca/device4/tls-cert.pem

  mkdir -p ../crypto-config/peerOrganizations/device4.net/users/Admin@device4.net

  echo
  echo "## Generate the org admin msp"
  echo
  fabric-ca-client enroll -u https://device4admin:device4adminpw@localhost:9054 --caname ca.device4.net -M ${PWD}/../crypto-config/peerOrganizations/device4.net/users/Admin@device4.net/msp --tls.certfiles ${PWD}/fabric-ca/device4/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device4.net/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/device4.net/users/Admin@device4.net/msp/config.yaml

}

createcertificatesForDevice4

