export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=${PWD}/crypto-config/peerOrganizations/device1.net/tlsca/tlsca.device1.net-cert.pem
export ENDORSER_DEVICE1_CA=${PWD}/crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/ca.crt
export ENDORSER_DEVICE3_CA=${PWD}/../vm3/crypto-config/peerOrganizations/device3.net/peers/endorser.device3.net/tls/ca.crt
export ENDORSER_DEVICE4_CA=${PWD}/../vm4/crypto-config/peerOrganizations/device2.net/peers/endorser.device2.net/tls/ca.crt
export FABRIC_CFG_PATH=${PWD}/../../artifacts/channel/config/


export CHANNEL_NAME=mychannel

setGlobalsForEndorserDevice1() {
    export CORE_PEER_LOCALMSPID="Device1MSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$ENDORSER_DEVICE1_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/crypto-config/peerOrganizations/device1.net/users/Admin@device1.net/msp
    export CORE_PEER_ADDRESS=localhost:7051
}

presetup() {
    echo Vendoring Go dependencies ...
    pushd ./../../artifacts/chaincode/src
    GO111MODULE=on go mod vendor
    popd
    echo Finished vendoring Go dependencies
}
# presetup

CHANNEL_NAME="mychannel"
CC_RUNTIME_LANGUAGE="golang"
VERSION="1"
CC_SRC_PATH="./../../artifacts/chaincode/src"
CC_NAME="IoT-cc"

packageChaincode() {
    rm -rf ${CC_NAME}.tar.gz
    setGlobalsForEndorserDevice1
    peer lifecycle chaincode package ${CC_NAME}.tar.gz \
        --path ${CC_SRC_PATH} --lang ${CC_RUNTIME_LANGUAGE} \
        --label ${CC_NAME}_${VERSION}
    echo "===================== Chaincode is packaged on endorser.org1 ===================== "
}
# packageChaincode

installChaincode() {
    setGlobalsForEndorserDevice1
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on endorser.org1 ===================== "

}

# installChaincode

queryInstalled() {
    setGlobalsForEndorserDevice1
    peer lifecycle chaincode queryinstalled >&log.txt
    cat log.txt
    PACKAGE_ID=$(sed -n "/${CC_NAME}_${VERSION}/{s/^Package ID: //; s/, Label:.*$//; p;}" log.txt)
    echo PackageID is ${PACKAGE_ID}
    echo "===================== Query installed successful on endorser.org1 on channel ===================== "
}

# queryInstalled

approveForMyOrg1() {
    setGlobalsForEndorserDevice1
    # set -x
    # Replace localhost with your orderer's vm IP address
    peer lifecycle chaincode approveformyorg --orderer localhost:7050 \
        --ordererTLSHostnameOverride orderer1.device1.net --tls \
        --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} \
        --init-required --package-id ${PACKAGE_ID} \
        --sequence ${VERSION}
    # set +x

    echo "===================== chaincode approved from org 1 ===================== "
}

# queryInstalled
# approveForMyOrg1

checkCommitReadyness() {
    setGlobalsForEndorserDevice1
    peer lifecycle chaincode checkcommitreadiness \
        --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} \
        --sequence ${VERSION} --output json --init-required
    echo "===================== checking commit readyness from org 1 ===================== "
}

# checkCommitReadyness

commitChaincodeDefination() {
    setGlobalsForEndorserDevice1
    peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer1.device1.net \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        --channelID $CHANNEL_NAME --name ${CC_NAME} \
        --peerAddresses localhost:7051 --tlsRootCertFiles $ENDORSER_DEVICE1_CA \
        --peerAddresses localhost:9051 --tlsRootCertFiles $ENDORSER_DEVICE4_CA \
        --version ${VERSION} --sequence ${VERSION} --init-required

        # --peerAddresses localhost:11051 --tlsRootCertFiles $ENDORSER_DEVICE3_CA \
        # --version ${VERSION} --sequence ${VERSION} --init-required
}

# commitChaincodeDefination

queryCommitted() {
    setGlobalsForEndorserDevice1
    peer lifecycle chaincode querycommitted --channelID $CHANNEL_NAME --name ${CC_NAME}

}

# queryCommitted

chaincodeInvokeInit() {
    setGlobalsForEndorserDevice1
    peer chaincode invoke -o localhost:7050 \
        --ordererTLSHostnameOverride orderer1.device1.net \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        -C $CHANNEL_NAME -n ${CC_NAME} \
        --peerAddresses localhost:9051 --tlsRootCertFiles $ENDORSER_DEVICE4_CA \
         --peerAddresses localhost:11051 --tlsRootCertFiles $ENDORSER_DEVICE3_CA \
        --isInit -c '{"Args":["init"]}'

}

 # --peerAddresses localhost:7051 --tlsRootCertFiles $ENDORSER_DEVICE1_CA \

# chaincodeInvokeInit

chaincodeInvoke() {
    setGlobalsForEndorserDevice1

    ## Create Project
    peer chaincode invoke -o orderer1.device1.net:7050 \
        --ordererTLSHostnameOverride orderer1.device1.net \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        -C $CHANNEL_NAME -n ${CC_NAME} \
        --peerAddresses endorser.device1.net:7051 --tlsRootCertFiles $ENDORSER_DEVICE1_CA \
        --peerAddresses endorser.device2.example.com:9051 --tlsRootCertFiles $ENDORSER_DEVICE4_CA   \
        -c '{"function":"createAsset","Args":["{\"asset\":[{\"@assetType\":\"project\",\"project\":\"Project B\"}]}"]}'
    
    ## Create Project
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer1.device1.net \
    #     --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
    #     -C $CHANNEL_NAME -n ${CC_NAME} \
    #     --peerAddresses localhost:7051 --tlsRootCertFiles $ENDORSER_DEVICE1_CA \
    #     --peerAddresses localhost:9051 --tlsRootCertFiles $ENDORSER_DEVICE4_CA   \
    #     --peerAddresses localhost:11051 --tlsRootCertFiles $ENDORSER_DEVICE3_CA \
    #     -c '{"function":"createAsset","Args":["{\"asset\":[{\"@assetType\":\"project\",\"amount\":300,\"claimAmount\":20,\"project\":\"Project B\"}]}"]}'

    ## Tokenize Carbon Offset
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer1.device1.net \
    #     --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
    #     -C $CHANNEL_NAME -n ${CC_NAME} \
    #     --peerAddresses localhost:7051 --tlsRootCertFiles $ENDORSER_DEVICE1_CA \
    #     --peerAddresses localhost:9051 --tlsRootCertFiles $ENDORSER_DEVICE4_CA   \
    #     --peerAddresses localhost:11051 --tlsRootCertFiles $ENDORSER_DEVICE3_CA \
    #     -c '{"function":"tokenizeCarbonCredit","Args":["{\"project\":{\"@assetType\":\"project\",\"@key\":\"project:407b163c-5673-5221-a237-b7472ab8b107\"},\"amount\":100}"]}'

    ## Transfer Carbon Credit
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer1.device1.net \
    #     --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
    #     -C $CHANNEL_NAME -n ${CC_NAME} \
    #     --peerAddresses localhost:7051 --tlsRootCertFiles $ENDORSER_DEVICE1_CA \
    #     --peerAddresses localhost:9051 --tlsRootCertFiles $ENDORSER_DEVICE4_CA \
    #     --peerAddresses localhost:11051 --tlsRootCertFiles $ENDORSER_DEVICE3_CA \
    #     -c "{\"function\":\"transferCarbonCredit\",\"Args\":[\"{\\\"fromProject\\\":{\\\"@assetType\\\":\\\"project\\\",\\\"@key\\\":\\\"project:428c622b-13ae-5509-9326-d9cff2d7ca0f\\\"},\\\"toProject\\\":{\\\"@assetType\\\":\\\"project\\\",\\\"@key\\\":\\\"project:407b163c-5673-5221-a237-b7472ab8b107\\\"},\\\"amount\\\":10}\"]}"

    ## Init ledger
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer1.device1.net \
    #     --tls $CORE_PEER_TLS_ENABLED \
    #     --cafile $ORDERER_CA \
    #     -C $CHANNEL_NAME -n ${CC_NAME} \
    #     --peerAddresses localhost:7051 --tlsRootCertFiles $ENDORSER_DEVICE1_CA \
    #     --peerAddresses localhost:9051 --tlsRootCertFiles $ENDORSER_DEVICE4_CA \
    #     -c '{"function": "initLedger","Args":[]}'

}

# chaincodeInvoke

chaincodeQuery() {
    setGlobalsForEndorserDevice1

    # Query All Asset
    peer chaincode query -C $CHANNEL_NAME -n ${CC_NAME} -c '{"function":"search","Args":["{\"query\":{\"selector\":{\"@assetType\":\"project\"}}}"]}'
}

# chaincodeQuery

# Run this function if you add any new dependency in chaincode
presetup

packageChaincode
installChaincode
queryInstalled
# approveForMyOrg1
# checkCommitReadyness

# commitChaincodeDefination

# approveForMyOrg2

# checkCommitReadyness
# queryCommitted
# chaincodeInvokeInit
# sleep 5
# chaincodeInvoke
# sleep 3
# chaincodeQuery
