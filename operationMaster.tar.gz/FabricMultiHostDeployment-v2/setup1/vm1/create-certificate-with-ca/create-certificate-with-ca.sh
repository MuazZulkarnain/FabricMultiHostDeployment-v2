createcertificatesForOrg1() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p ../crypto-config/peerOrganizations/device1.net/
  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config/peerOrganizations/device1.net/

  fabric-ca-client enroll -u https://admin:adminpw@localhost:7054 --caname ca.device1.net --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-device1-net.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-device1-net.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-device1-net.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-device1-net.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config/peerOrganizations/device1.net/msp/config.yaml

  echo
  echo "Register endorser"
  echo
  fabric-ca-client register --caname ca.device1.net --id.name endorser --id.secret endorserpw --id.type peer --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  echo
  echo "Register orderer1"
  echo
  fabric-ca-client register --caname ca.device1.net --id.name orderer1 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  echo
  echo "Register user"
  echo
  fabric-ca-client register --caname ca.device1.net --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  echo
  echo "Register the org admin"
  echo
  fabric-ca-client register --caname ca.device1.net --id.name device1admin --id.secret device1adminpw --id.type admin  --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  mkdir -p ../crypto-config/peerOrganizations/device1.net/peers

  # -----------------------------------------------------------------------------------
  #  Peer 0
  mkdir -p ../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net

  echo
  echo "## Generate the endorser msp"
  echo
  fabric-ca-client enroll -u https://endorser:endorserpw@localhost:7054 --caname ca.device1.net -M ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/msp --csr.hosts endorser.device1.net --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/msp/config.yaml

  echo
  echo "## Generate the endorser-tls certificates"
  echo
  fabric-ca-client enroll -u https://endorser:endorserpw@localhost:7054 --caname ca.device1.net -M ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls --enrollment.profile tls --csr.hosts endorser.device1.net --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/ca.crt
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/signcerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/server.crt
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/keystore/* ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/server.key

  mkdir ${PWD}/../crypto-config/peerOrganizations/device1.net/msp/tlscacerts
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/msp/tlscacerts/ca.crt

  mkdir ${PWD}/../crypto-config/peerOrganizations/device1.net/tlsca
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/tlsca/tlsca.device1.net-cert.pem

  mkdir ${PWD}/../crypto-config/peerOrganizations/device1.net/ca
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/msp/cacerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/ca/ca.device1.net-cert.pem

  # ------------------------------------------------------------------------------------------------
 
  # -----------------------------------------------------------------------------------
  #  Orderer 1
  mkdir -p ../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net

  echo
  echo "## Generate the orderer1 msp"
  echo
  fabric-ca-client enroll -u https://orderer1:ordererpw@localhost:7054 --caname ca.device1.net -M ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/msp --csr.hosts orderer1.device1.net --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/msp/config.yaml

  echo
  echo "## Generate the orderer1-tls certificates"
  echo
  fabric-ca-client enroll -u https://orderer1:ordererpw@localhost:7054 --caname ca.device1.net -M ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls --enrollment.profile tls --csr.hosts orderer1.device1.net --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls/ca.crt
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls/signcerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls/server.crt
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls/keystore/* ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls/server.key

  mkdir ${PWD}/../crypto-config/peerOrganizations/device1.net/msp/tlscacerts
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/msp/tlscacerts/ca.crt

  mkdir ${PWD}/../crypto-config/peerOrganizations/device1.net/tlsca
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/tlsca/tlsca.device1.net-cert.pem

  mkdir ${PWD}/../crypto-config/peerOrganizations/device1.net/ca
  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/orderers/orderer1.device1.net/msp/cacerts/* ${PWD}/../crypto-config/peerOrganizations/device1.net/ca/ca.device1.net-cert.pem

  # ------------------------------------------------------------------------------------------------

  mkdir -p ../crypto-config/peerOrganizations/device1.net/users
  mkdir -p ../crypto-config/peerOrganizations/device1.net/users/User1@device1.net

  echo
  echo "## Generate the user msp"
  echo
  fabric-ca-client enroll -u https://user1:user1pw@localhost:7054 --caname ca.device1.net -M ${PWD}/../crypto-config/peerOrganizations/device1.net/users/User1@device1.net/msp --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  mkdir -p ../crypto-config/peerOrganizations/device1.net/users/Admin@device1.net

  echo
  echo "## Generate the org admin msp"
  echo
  fabric-ca-client enroll -u https://device1admin:device1adminpw@localhost:7054 --caname ca.device1.net -M ${PWD}/../crypto-config/peerOrganizations/device1.net/users/Admin@device1.net/msp --tls.certfiles ${PWD}/fabric-ca/device1/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/device1.net/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/device1.net/users/Admin@device1.net/msp/config.yaml

}

createcertificatesForOrg1
