export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=${PWD}/crypto-config/peerOrganizations/device1.net/tlsca/tlsca.device1.net-cert.pem
export ENDORSER_DEVICE1_CA=${PWD}/crypto-config/peerOrganizations/device1.net/peers/endorser.device1.net/tls/ca.crt
export FABRIC_CFG_PATH=${PWD}/../../artifacts/channel/config/

export CHANNEL_NAME=mychannel

setGlobalsForEndorserDevice1(){
    export CORE_PEER_LOCALMSPID="Device1MSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$ENDORSER_DEVICE1_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/crypto-config/peerOrganizations/device1.net/users/Admin@device1.net/msp
    export CORE_PEER_ADDRESS=localhost:7051
}

createChannel(){
    rm -rf ./channel-artifacts/*
    setGlobalsForEndorserDevice1
    
    # Replace localhost with your orderer's vm IP address
    peer channel create -o localhost:7050 -c $CHANNEL_NAME \
    --ordererTLSHostnameOverride orderer1.device1.net \
    -f ./../../artifacts/channel/${CHANNEL_NAME}.tx --outputBlock ./../../artifacts/channel/${CHANNEL_NAME}.block \
    --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
}

# createChannel

joinChannel(){
    setGlobalsForEndorserDevice1
    peer channel join -b ./../../artifacts/channel/$CHANNEL_NAME.block
}

# joinChannel

updateAnchorPeers(){
    setGlobalsForEndorserDevice1
    # Replace localhost with your orderer's vm IP address
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer1.device1.net -c $CHANNEL_NAME -f ./../../artifacts/channel/${CORE_PEER_LOCALMSPID}anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    
}

createChannel
joinChannel
updateAnchorPeers