
# System channel
SYS_CHANNEL="sys-channel"

# channel name defaults to "mychannel"
CHANNEL_NAME="mychannel"

echo $CHANNEL_NAME

# Generate System Genesis block
configtxgen -profile OrdererGenesis -configPath . -channelID $SYS_CHANNEL  -outputBlock genesis.block


# Generate channel configuration block
configtxgen -profile BasicChannel -configPath . -outputCreateChannelTx ./mychannel.tx -channelID $CHANNEL_NAME

echo "#######    Generating anchor peer update for Device1MSP  ##########"
configtxgen -profile BasicChannel -configPath . -outputAnchorPeersUpdate ./Device1MSPanchors.tx -channelID $CHANNEL_NAME -asOrg Device1MSP

echo "#######    Generating anchor peer update for Device3MSP  ##########"
configtxgen -profile BasicChannel -configPath . -outputAnchorPeersUpdate ./Device3MSPanchors.tx -channelID $CHANNEL_NAME -asOrg Device3MSP

echo "#######    Generating anchor peer update for Device4MSP  ##########"
configtxgen -profile BasicChannel -configPath . -outputAnchorPeersUpdate ./Device4MSPanchors.tx -channelID $CHANNEL_NAME -asOrg Device4MSP